import { TestBed } from '@angular/core/testing';

import { HolidayPackageServiceService } from './holiday-package-service.service';

describe('HolidayPackageServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HolidayPackageServiceService = TestBed.get(HolidayPackageServiceService);
    expect(service).toBeTruthy();
  });
});
