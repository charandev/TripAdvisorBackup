import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "hotelfacility"
})
export class HotelfacilityPipe implements PipeTransform {
  transform(
    datas: any[],
    aircondition: any,
    television: any,
    star3: any,
    star4: any,
    star5: any
  ): any {
    if (
      (aircondition === false || aircondition === undefined) &&
      (television === false || television === undefined) &&
      (star3 === false || star3 === undefined) &&
      (star4 === false || star4 === undefined) &&
      (star5 === false || star5 === undefined)
    )
      return datas;

    return datas.filter(function(data) {
      if (aircondition === true) {
        for (let i = 0; i < data.facilities.length; i++) {
          if (data.facilities[i].search("Air Conditioning")) {
            console.log("air");

            return data;
          }
        }
      }

      if (television === true) {
        for (let i = 0; i < data.facilities.length; i++) {
          if (data.facilities[i].search("Television")) {
            console.log("tele");

            return data;
          }
        }
      }
    });
  }
}
