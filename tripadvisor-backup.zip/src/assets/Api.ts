export class Api{
// baseUrl:string="https://eswar-trip-advisor-api-dev.azurewebsites.net"
baseUrl:string="http://localhost:8080"
}