package com.mindtree.tripadvisor.searchflight.service;

public interface SearchFlightService {

}
