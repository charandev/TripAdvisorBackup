package com.mindtree.tripadvisor.searchflight.repository;

public interface SearchFlightRepository {

}
