package com.mindtree.tripadvisor.searchflight.service.impl;

public class SearchFlightServiceImpl {

}
