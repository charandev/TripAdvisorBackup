package com.mindtree.tripadvisor.searchflight.entity;

public class Flight {

}
