package com.mindtree.tripadvisor.holidaypackage.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.mindtree.tripadvisor.holidaypackage.dto.HolidayPackageDto;
import com.mindtree.tripadvisor.holidaypackage.dto.PlaceDto;
import com.mindtree.tripadvisor.holidaypackage.entity.HolidayPackage;
import com.mindtree.tripadvisor.holidaypackage.entity.Place;
import com.mindtree.tripadvisor.holidaypackage.exception.PlaceNotFoundException;
import com.mindtree.tripadvisor.holidaypackage.repository.PlaceRepository;
import com.mindtree.tripadvisor.holidaypackage.service.PlaceService;

@Service
public class PlaceServiceImpl implements PlaceService {


	@Autowired
	PlaceRepository placeRepository;
	private ModelMapper model= new ModelMapper();
	@Override
	public PlaceDto getPackagesByPlace(String name) throws PlaceNotFoundException{
		Optional<Place> placeOptional=placeRepository.findByDestinationIgnoreCase(name);
		placeOptional.orElseThrow(()-> new PlaceNotFoundException("Package for the respesctive place "+"'"+name+"'"+" is not found"));
		Place place= placeOptional.get();
		PlaceDto placeDto= new PlaceDto();
		placeDto=model.map(place, PlaceDto.class);
		return placeDto;
	}
	
	

}
