package com.mindtree.tripadvisor.holidaypackage.dto;

import java.util.Arrays;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mindtree.tripadvisor.holidaypackage.entity.Season;

public class PlaceDto {

	private int placeId;
	private String destination;
	private String description;
	@ManyToOne(cascade=CascadeType.ALL)
	private Season seasons;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="places")
	private List<HolidayPackageDto> packages;

	
	private String place_image;

	public int getPlace_id() {
		return placeId;
	}

	public void setPlace_id(int place_id) {
		this.placeId = place_id;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
       @JsonIgnore
	public Season getSeasons() {
		return seasons;
	}

	public void setSeasons(Season seasons) {
		this.seasons = seasons;
	}
    
	public List<HolidayPackageDto> getPackages() {
		return packages;
	}

	public void setPackages(List<HolidayPackageDto> packages) {
		this.packages = packages;
	}

	public String getPlace_image() {
		return place_image;
	}

	public void setPlace_image(String place_image) {
		this.place_image = place_image;
	}


	@Override
	public String toString() {
		return "PlaceDto [placeId=" + placeId + ", destination=" + destination + ", description=" + description
				+ ", seasons=" + seasons + ", packages=" + packages + ", place_image=" + place_image + "]";
	}

	public PlaceDto(int place_id, String destination, String description, Season seasons, List<HolidayPackageDto> packages,
			String place_image) {
		super();
		this.placeId = place_id;
		this.destination = destination;
		this.description = description;
		this.seasons = seasons;
		this.packages = packages;
		this.place_image = place_image;
	}

	public PlaceDto() {
		super();
	}
}
