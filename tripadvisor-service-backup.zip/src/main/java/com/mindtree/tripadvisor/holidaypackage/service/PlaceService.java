package com.mindtree.tripadvisor.holidaypackage.service;

import java.util.List;

import com.mindtree.tripadvisor.holidaypackage.dto.HolidayPackageDto;
import com.mindtree.tripadvisor.holidaypackage.dto.PlaceDto;
import com.mindtree.tripadvisor.holidaypackage.exception.PlaceNotFoundException;


public interface PlaceService {
	
	public PlaceDto getPackagesByPlace(String name) throws PlaceNotFoundException;


}
