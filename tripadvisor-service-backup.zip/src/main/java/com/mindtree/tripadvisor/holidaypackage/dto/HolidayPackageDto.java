package com.mindtree.tripadvisor.holidaypackage.dto;



import java.util.List;

import javax.persistence.CascadeType;


import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.tripadvisor.holidaypackage.entity.Booking;



public class HolidayPackageDto {

	private int packageId;
	private String packageType;
	private String packageName;
	private int days;
	private int nights;
	private long budget;

	@ManyToOne(cascade=CascadeType.ALL)
	private PlaceDto places;
	
	private String package_image;
	
	private String package_description;
	
	public HolidayPackageDto() {
		
	}
	@JsonIgnoreProperties("holidayPackage")
	private List<Booking> bookings;

	public int getPackage_id() {
		return packageId;
	}
	public void setPackage_id(int package_id) {
		this.packageId = package_id;
	}
	public String getPackage_type() {
		return packageType;
	}
	public void setPackage_type(String package_type) {
		this.packageType = package_type;
	}
	public String getPackage_name() {
		return packageName;
	}
	public void setPackage_name(String package_name) {
		this.packageName = package_name;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public int getNights() {
		return nights;
	}
	public void setNights(int nights) {
		this.nights = nights;
	}
	public long getBudget() {
		return budget;
	}
	public void setBudget(long budget) {
		this.budget = budget;
	}
	@JsonIgnore
	public PlaceDto getPlaces() {
		return places;
	}
	public void setPlaces(PlaceDto places) {
		this.places = places;
	}
	public String getPackage_image() {
		return package_image;
	}
	public void setPackage_image(String package_image) {
		this.package_image = package_image;
	}
	public String getPackage_description() {
		return package_description;
	}
	public void setPackage_description(String package_description) {
		this.package_description = package_description;
	}
	public List<Booking> getBookings() {
		return bookings;
	}
	public void setBookings(List<Booking> bookings) {
		this.bookings = bookings;
	}
	public HolidayPackageDto(int packageId, String packageType, String packageName, int days, int nights, long budget,
			PlaceDto places, String package_image, String package_description, List<Booking> bookings) {
		super();
		this.packageId = packageId;
		this.packageType = packageType;
		this.packageName = packageName;
		this.days = days;
		this.nights = nights;
		this.budget = budget;
		this.places = places;
		this.package_image = package_image;
		this.package_description = package_description;
		this.bookings = bookings;
	}
	@Override
	public String toString() {
		return "HolidayPackageDto [packageId=" + packageId + ", packageType=" + packageType + ", packageName="
				+ packageName + ", days=" + days + ", nights=" + nights + ", budget=" + budget + ", places=" + places
				+ ", package_image=" + package_image + ", package_description=" + package_description + ", bookings="
				+ bookings + "]";
	}


	
	
}
