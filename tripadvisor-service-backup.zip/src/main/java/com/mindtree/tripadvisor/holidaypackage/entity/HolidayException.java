package com.mindtree.tripadvisor.holidaypackage.entity;

public class HolidayException {
	private String message;

	public HolidayException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HolidayException(String message2) {
	this.message=message2;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	

}
