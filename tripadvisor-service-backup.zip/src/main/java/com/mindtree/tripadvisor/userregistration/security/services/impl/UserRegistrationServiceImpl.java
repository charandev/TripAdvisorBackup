package com.mindtree.tripadvisor.userregistration.security.services.impl;

import java.util.HashSet;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.mindtree.tripadvisor.userregistration.entity.Role;
import com.mindtree.tripadvisor.userregistration.entity.RoleName;
import com.mindtree.tripadvisor.userregistration.entity.User;
import com.mindtree.tripadvisor.userregistration.exception.EmailAlreadyExistsException;
import com.mindtree.tripadvisor.userregistration.exception.UserNameAlreadyExistException;
import com.mindtree.tripadvisor.userregistration.exception.UserRegistractionException;
import com.mindtree.tripadvisor.userregistration.message.request.SignUpForm;
import com.mindtree.tripadvisor.userregistration.repository.RoleRepository;
import com.mindtree.tripadvisor.userregistration.repository.UserRepository;
import com.mindtree.tripadvisor.userregistration.security.services.UserRegistrationService;



@Service
public class UserRegistrationServiceImpl implements UserRegistrationService{

	
	@Autowired
	PasswordEncoder encoder;
	
	
	@Autowired
	RoleRepository roleRepository;
	
	@Autowired
	UserRepository userRepository;

	private JavaMailSender javaMailSender;
	
	
	@Autowired
	public UserRegistrationServiceImpl(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}
	
	@Override
	public String addUser(@Valid SignUpForm signUpRequest) throws UserRegistractionException {
		if (userRepository.existsByUsername(signUpRequest.getUsername())) 
		{
			throw new UserNameAlreadyExistException("Fail -> Username is already taken!");
		}
		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			throw new EmailAlreadyExistsException("Fail -> Email is already in use!");
		}
		User user = new User(signUpRequest.getName(), signUpRequest.getUsername(), signUpRequest.getEmail(),
				encoder.encode(signUpRequest.getPassword()));
		Set<String> strRoles = signUpRequest.getRole();
		Set<Role> roles = new HashSet<>();

		strRoles.forEach(role -> {
			switch (role) {
			case "admin":
				Role adminRole = roleRepository.findByName(RoleName.ROLE_ADMIN)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(adminRole);

				break;
			case "pm":
				Role pmRole = roleRepository.findByName(RoleName.ROLE_PM)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(pmRole);

				break;
			default:
				Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(userRole);
			}
		});

		user.setRoles(roles);
		if(userRepository.save(user)!=null)
		{
		
			sendEntrymail(signUpRequest.getEmail());
		
			return "User ristered successfully!";
		}
		return "unsucessfully";
		
		
	}

	private void sendEntrymail(String email) {
		
		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo(email);
		mail.setSubject("TripAdvisor");
		mail.setText("Welcome to TripAdvisor" );
		
		javaMailSender.send(mail);
		
	}



	
}
