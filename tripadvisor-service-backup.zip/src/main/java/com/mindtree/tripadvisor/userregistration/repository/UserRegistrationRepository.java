package com.mindtree.tripadvisor.userregistration.repository;

public interface UserRegistrationRepository {

}
