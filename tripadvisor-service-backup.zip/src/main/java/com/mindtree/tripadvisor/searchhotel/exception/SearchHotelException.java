package com.mindtree.tripadvisor.searchhotel.exception;

public class SearchHotelException {

}
