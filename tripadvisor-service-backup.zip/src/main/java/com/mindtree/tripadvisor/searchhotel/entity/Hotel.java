/**
 * 
 */
package com.mindtree.tripadvisor.searchhotel.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author M1056135
 *
 */
@Entity
public class Hotel {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int hotelId;
	@Column(columnDefinition = "text")
	private String area;
	@Column(columnDefinition = "text")
	private String city;
	@Column(columnDefinition = "text")
	private String country;
	@Column(name = "hotel_description", columnDefinition = "text")
	private String hotelDescription;
	@Column(name = "hotel_facilities", columnDefinition = "text")
	private String hotelFacilities;
	@Column(name = "hotel_star_rating", columnDefinition = "text")
	private String hotelStarRating;
	@Column(name = "image_urls", columnDefinition = "text")
	private String imageUrls;
	@Column(columnDefinition = "text")
	private String landmark;
	@Column(columnDefinition = "text")
	private String locality;
	@Column(columnDefinition = "text")
	private String pageurl;
	@Column(name = "property_name", columnDefinition = "text")
	private String propertyName;
	@Column(name = "property_type", columnDefinition = "text")
	private String propertyType;
	@Column(name = "room_count")
	private int roomCount;
	@Column(name = "room_facilities", columnDefinition = "text")
	private String roomFacilities;
	@Column(columnDefinition = "text")
	private String state;
	@Column(name = "review_count", columnDefinition = "text")
	private int reviewCount;
	@Column(name = "review_rating", columnDefinition = "text")
	private String reviewRating;
	@Column(name = "stay_review_rating", columnDefinition = "text")
	private String stayReviewRating;
	@Column(name = "tripadvisor_seller_rating", columnDefinition = "text")
	private String tripadvisorSellerRating;
	@Column(columnDefinition = "text")
	private String address;
	private int price;

	/**
	 * 
	 */
	public Hotel() {
		super();
	}

	/**
	 * @param hotelId
	 * @param area
	 * @param city
	 * @param country
	 * @param hotelDescription
	 * @param hotelFacilities
	 * @param hotelStarRating
	 * @param imageUrls
	 * @param landmark
	 * @param locality
	 * @param pageurl
	 * @param propertyName
	 * @param propertyType
	 * @param roomCount
	 * @param roomFacilities
	 * @param state
	 * @param reviewCount
	 * @param reviewRating
	 * @param stayReviewRating
	 * @param tripadvisorSellerRating
	 * @param address
	 * @param price
	 */
	public Hotel(int hotelId, String area, String city, String country, String hotelDescription, String hotelFacilities,
			String hotelStarRating, String imageUrls, String landmark, String locality, String pageurl,
			String propertyName, String propertyType, int roomCount, String roomFacilities, String state,
			int reviewCount, String reviewRating, String stayReviewRating, String tripadvisorSellerRating,
			String address, int price) {
		super();
		this.hotelId = hotelId;
		this.area = area;
		this.city = city;
		this.country = country;
		this.hotelDescription = hotelDescription;
		this.hotelFacilities = hotelFacilities;
		this.hotelStarRating = hotelStarRating;
		this.imageUrls = imageUrls;
		this.landmark = landmark;
		this.locality = locality;
		this.pageurl = pageurl;
		this.propertyName = propertyName;
		this.propertyType = propertyType;
		this.roomCount = roomCount;
		this.roomFacilities = roomFacilities;
		this.state = state;
		this.reviewCount = reviewCount;
		this.reviewRating = reviewRating;
		this.stayReviewRating = stayReviewRating;
		this.tripadvisorSellerRating = tripadvisorSellerRating;
		this.address = address;
		this.price = price;
	}

	/**
	 * @return the hotelId
	 */
	public int getHotelId() {
		return hotelId;
	}

	/**
	 * @param hotelId the hotelId to set
	 */
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	/**
	 * @return the area
	 */
	public String getArea() {
		return area;
	}

	/**
	 * @param area the area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the hotelDescription
	 */
	public String getHotelDescription() {
		return hotelDescription;
	}

	/**
	 * @param hotelDescription the hotelDescription to set
	 */
	public void setHotelDescription(String hotelDescription) {
		this.hotelDescription = hotelDescription;
	}

	/**
	 * @return the hotelFacilities
	 */
	public String getHotelFacilities() {
		return hotelFacilities;
	}

	/**
	 * @param hotelFacilities the hotelFacilities to set
	 */
	public void setHotelFacilities(String hotelFacilities) {
		this.hotelFacilities = hotelFacilities;
	}

	/**
	 * @return the hotelStarRating
	 */
	public String getHotelStarRating() {
		return hotelStarRating;
	}

	/**
	 * @param hotelStarRating the hotelStarRating to set
	 */
	public void setHotelStarRating(String hotelStarRating) {
		this.hotelStarRating = hotelStarRating;
	}

	/**
	 * @return the imageUrls
	 */
	public String getImageUrls() {
		return imageUrls;
	}

	/**
	 * @param imageUrls the imageUrls to set
	 */
	public void setImageUrls(String imageUrls) {
		this.imageUrls = imageUrls;
	}

	/**
	 * @return the landmark
	 */
	public String getLandmark() {
		return landmark;
	}

	/**
	 * @param landmark the landmark to set
	 */
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	/**
	 * @return the locality
	 */
	public String getLocality() {
		return locality;
	}

	/**
	 * @param locality the locality to set
	 */
	public void setLocality(String locality) {
		this.locality = locality;
	}

	/**
	 * @return the pageurl
	 */
	public String getPageurl() {
		return pageurl;
	}

	/**
	 * @param pageurl the pageurl to set
	 */
	public void setPageurl(String pageurl) {
		this.pageurl = pageurl;
	}

	/**
	 * @return the propertyName
	 */
	public String getPropertyName() {
		return propertyName;
	}

	/**
	 * @param propertyName the propertyName to set
	 */
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	/**
	 * @return the propertyType
	 */
	public String getPropertyType() {
		return propertyType;
	}

	/**
	 * @param propertyType the propertyType to set
	 */
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	/**
	 * @return the roomCount
	 */
	public int getRoomCount() {
		return roomCount;
	}

	/**
	 * @param roomCount the roomCount to set
	 */
	public void setRoomCount(int roomCount) {
		this.roomCount = roomCount;
	}

	/**
	 * @return the roomFacilities
	 */
	public String getRoomFacilities() {
		return roomFacilities;
	}

	/**
	 * @param roomFacilities the roomFacilities to set
	 */
	public void setRoomFacilities(String roomFacilities) {
		this.roomFacilities = roomFacilities;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the reviewCount
	 */
	public int getReviewCount() {
		return reviewCount;
	}

	/**
	 * @param reviewCount the reviewCount to set
	 */
	public void setReviewCount(int reviewCount) {
		this.reviewCount = reviewCount;
	}

	/**
	 * @return the reviewRating
	 */
	public String getReviewRating() {
		return reviewRating;
	}

	/**
	 * @param reviewRating the reviewRating to set
	 */
	public void setReviewRating(String reviewRating) {
		this.reviewRating = reviewRating;
	}

	/**
	 * @return the stayReviewRating
	 */
	public String getStayReviewRating() {
		return stayReviewRating;
	}

	/**
	 * @param stayReviewRating the stayReviewRating to set
	 */
	public void setStayReviewRating(String stayReviewRating) {
		this.stayReviewRating = stayReviewRating;
	}

	/**
	 * @return the tripadvisorSellerRating
	 */
	public String getTripadvisorSellerRating() {
		return tripadvisorSellerRating;
	}

	/**
	 * @param tripadvisorSellerRating the tripadvisorSellerRating to set
	 */
	public void setTripadvisorSellerRating(String tripadvisorSellerRating) {
		this.tripadvisorSellerRating = tripadvisorSellerRating;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the price
	 */
	public int getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", area=" + area + ", city=" + city + ", country=" + country
				+ ", hotelDescription=" + hotelDescription + ", hotelFacilities=" + hotelFacilities
				+ ", hotelStarRating=" + hotelStarRating + ", imageUrls=" + imageUrls + ", landmark=" + landmark
				+ ", locality=" + locality + ", pageurl=" + pageurl + ", propertyName=" + propertyName
				+ ", propertyType=" + propertyType + ", roomCount=" + roomCount + ", roomFacilities=" + roomFacilities
				+ ", state=" + state + ", reviewCount=" + reviewCount + ", reviewRating=" + reviewRating
				+ ", stayReviewRating=" + stayReviewRating + ", tripadvisorSellerRating=" + tripadvisorSellerRating
				+ ", address=" + address + ", price=" + price + "]";
	}

}
